# 中华文物数字文化展示网页 — 项目说明

## 项目概述

这是一个基于 HTML5 + CSS3 + 原生 JavaScript + Three.js 的沉浸式文物展示网站，名为《中华文物》。网站集器物、石刻、历史、文物修复与数字化推广于一体，包含首页及多个专题页面。

## 技术栈

- **前端**: HTML5, CSS3 (Flexbox/Grid, CSS自定义属性, backdrop-filter, CSS 3D Transform), 原生 JavaScript (ES6+)
- **3D引擎**: Three.js (ES Module + importmap)
  - GLTFLoader + DRACOLoader 加载压缩 GLB 模型
  - OrbitControls 交互控制
  - CSS2DRenderer 热点标注
  - RoomEnvironment 环境光照
- **动画**: Canvas 2D API + requestAnimationFrame (6组交互特效)
- **字体**: Google Fonts (Ma Shan Zheng, Noto Serif SC, Noto Sans SC)
- **无构建工具**: 纯静态文件，无 Webpack/Vite，直接通过 HTTP 服务器运行

## 文件结构

```
/
├── index.html                  # 首页（7大板块，6组Canvas动画）
├── museum-3d.html              # 指尖博物馆列表页（150+文物，8大分类，搜索筛选）
├── museum-3d.js                # 博物馆3D交互逻辑（Three.js场景）
│
├── sanyangzun-3d.html           # 三羊尊 3D鉴赏页面
├── museum-jiagu.html           # 击鼓说唱俑 3D鉴赏页面
├── museum-huniu.html           # 虎钮淳于 3D鉴赏页面
├── museum-niao.html            # 青铜鸟 3D鉴赏页面
├── sanyangzun-3d.html           # 三羊尊3D
├── museum-jiagu.js              # 击鼓说唱俑3D逻辑
├── museum-huniu.js              # 虎钮淳于3D逻辑
├── museum-niao.js               # 青铜鸟3D逻辑
├── museum-index.html            # 博物馆索引页
│
├── stone-cover.html             # 石刻封面页
├── stone-detail.html            # 石刻详情页
├── vessels-cover.html           # 器物封面页
├── vessels-detail.html          # 器物详情页
├── history-cover.html           # 历史封面页
├── history-detail.html          # 历史详情页
├── restoration-cover.html       # 文物修复封面页
├── restoration-detail.html      # 文物修复详情页
├── promotion-cover.html         # 数字化推广封面页
├── promotion-detail.html       # 数字化推广详情页
├── dazu-rock-carvings.html      # 大足石刻专题页
│
├── canvas-effects.js            # Canvas动画效果集
├── canvas-effects-complete.js   # Canvas动画补充
├── canvas-all.js                # Canvas动画整合版
│
├── images/                      # 图片资源目录（130+张文物图片）
├── *.glb                        # 3D模型文件（4个DRACO压缩GLB）
└── GEMINI-README.md             # 本文件
```

## 核心页面说明

### 1. index.html — 首页

首页包含7大板块，每个板块有独立的Canvas交互动画：

| 板块 | Canvas ID | 动画类名 | 效果说明 |
|------|-----------|----------|----------|
| Hero | hero-canvas | HeroTransitionEffect | 鼠标视差图片切换 + 尘埃粒子 + 光束 |
| 器之灵 | vessels-canvas | VesselParticleEffect | 粒子消散聚合 |
| 石之韵 | stone-canvas | StonePeelEffect | 石刻揭幕（mask遮罩） |
| 史之痕 | history-canvas | HistoryScrollEffect | 历史长卷滚动 |
| 文物修复 | restoration-canvas | RestorationTechEffect | 修复光影 |
| 推广 | promotion-canvas | PromotionLanternEffect | 灯笼飘落 + 花瓣 |

技术要点：
- CSS变量: `--color-primary: #c9a962`, `--color-bg-dark: #0a0a0f`, `--glass-bg`, `--glass-border`
- backdrop-filter: blur() 玻璃拟态导航栏
- IntersectionObserver 滚动渐显
- CSS 3D翻转卡片: perspective + preserve-3d + rotateY + backface-visibility
- clamp() 响应式字号
- Canvas globalCompositeOperation: 'screen' / 'destination-out' / 'destination-in'

### 2. museum-3d.html — 指尖博物馆

- 150+件文物数据，8大分类（青铜器/陶器/石雕石刻/玉器/金银器/瓷器/书画/漆木器）
- 关键词搜索 + 分类筛选 + 分页加载（24件/页）
- 文物卡片点击弹出详情弹窗（modal）
- 3D角标显示 + 3D模型查看按钮跳转
- 图片懒加载（Intersection Observer）+ onerror回退

### 3. 独立3D鉴赏页面（4个）

| 页面 | 模型文件 | 文物名称 | 朝代 |
|------|----------|----------|------|
| sanyangzun-3d.html | sanyangzun-compressed.glb | 三羊尊 | 商代晚期 |
| museum-jiagu.html | jiagu-web.glb | 击鼓说唱俑 | 东汉 |
| museum-huniu.html | huniu-web.glb | 虎钮淳于 | 战国 |
| museum-niao.html | niao-web.glb | 青铜鸟 | 商周 |

每个3D页面功能：
- Three.js + GLTFLoader + DRACOLoader 加载GLB模型
- OrbitControls 鼠标拖拽旋转/缩放
- 自动巡游模式（tour mode）
- 热点标注（CSS2DRenderer / CSS2DObject）
- 环境光照（RoomEnvironment）
- 缓动相机动画（easeOutCubic）
- 粒子尘埃效果（Float32Array + BufferGeometry + PointsMaterial）
- 信息面板（文物介绍、特征标签、配色信息）

## 手势控制系统需求

请在现有项目基础上添加 **Webcam手势控制系统**，具体需求如下：

### 目标

通过摄像头捕捉用户手势，实现无接触式交互控制3D文物鉴赏和页面操作。

### 推荐技术方案

- **MediaPipe Hands** (Google) 用于手部21个关键点检测
- **手势识别**: 基于关键点位置关系自定义手势
- **Three.js集成**: 手势数据驱动 OrbitControls / Camera

### 需要实现的手势

| 手势 | 动作 | 对应功能 |
|------|------|----------|
| 张开手掌（五指伸展） | 手掌左右移动 | 3D模型旋转（Y轴） |
| 张开手掌（五指伸展） | 手掌上下移动 | 3D模型旋转（X轴） |
| 握拳 | — | 暂停旋转/锁定当前视角 |
| 捏合（拇指+食指） | 两指距离变化 | 缩放模型 |
| 食指指向 | 左/右滑动 | 切换上一个/下一个文物 |
| 手掌翻转（掌心朝向摄像头/背向） | — | 切换巡游模式开/关 |
| 双手合十 | — | 重置视角到默认位置 |

### 集成位置

1. **3D鉴赏页面**（sanyangzun-3d.html, museum-jiagu.html, museum-huniu.html, museum-niao.html）:
   - 在页面右下角添加手势控制面板（可折叠）
   - 摄像头预览窗口（小窗口，可隐藏）
   - 手势状态指示器（当前识别到的手势名称）
   - 手势开关按钮（开启/关闭手势模式）

2. **museum-3d.html 文物列表页**:
   - 食指左/右滑动 = 翻页
   - 手掌悬停在卡片上方 = 模拟点击打开详情

3. **index.html 首页**:
   - 手掌左右滑动 = 滚动到下一个板块

### 实现要求

- 手势控制为**可选增强功能**，不破坏现有鼠标/触摸交互
- 添加 `gesture-control.js` 作为独立模块，按需引入
- 摄像头视频流需要用户明确授权后才能开启
- 性能优化：手势检测帧率控制在30fps，避免阻塞渲染循环
- 视觉反馈：识别到手势时在屏幕上显示半透明手势图标和提示文字

### 代码风格要求

- 使用原生JavaScript（ES6+），不引入React/Vue等框架
- Three.js相关代码使用现有importmap方式引入
- CSS样式与现有深色金色主题保持一致
- 添加充分的中文注释

## 运行方式

```bash
# 在项目根目录启动本地HTTP服务器
python -m http.server 8080

# 或使用 npx
npx serve

# 访问
http://localhost:8080/index.html          # 首页
http://localhost:8080/museum-3d.html      # 指尖博物馆
http://localhost:8080/sanyangzun-3d.html   # 三羊尊3D鉴赏
```

## 注意事项

- 3D模型使用DRACO压缩，需要DRACOLoader解码
- 所有页面间通过相对路径链接
- 图片资源在 images/ 目录下
- 网站已部署至GitHub Pages，支持移动端访问
